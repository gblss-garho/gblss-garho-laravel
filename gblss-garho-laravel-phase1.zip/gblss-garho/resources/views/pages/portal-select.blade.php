@extends('layouts.app')

@section('title', 'Select Portal')

@section('content')
    <h1>Portals</h1>
    <p>Admin / Teacher / Parent / Student login goes here — Phase 2.</p>
@endsection
