<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public site (Phase 7)
|--------------------------------------------------------------------------
*/
Route::get('/', function () {
    return view('pages.home');
})->name('home');

/*
|--------------------------------------------------------------------------
| Portals (Phase 2 wires up auth + role middleware here)
|--------------------------------------------------------------------------
| Example once auth exists:
| Route::middleware(['auth', 'role:admin'])->prefix('admin')->group(...);
*/
Route::get('/portal', function () {
    return view('pages.portal-select');
})->name('portal.select');
